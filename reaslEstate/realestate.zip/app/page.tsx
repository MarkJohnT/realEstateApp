"use client"
import { useAuth } from "../src/components/auth-provider"
import { LoginForm } from "../src/components/login-form"
import { AdminDashboard } from "../src/components/admin-dashboard"

function Page() {
  const { user, profile } = useAuth()

  if (!user) {
    return <LoginForm onSuccess={() => window.location.reload()} />
  }

  if (profile?.role === "admin") {
    return <AdminDashboard />
  }

  // For regular users, show the main real estate app
  return (
    <div>
      <p>Redirecting to main app...</p>
      <script>{typeof window !== "undefined" && window.location.reload()}</script>
    </div>
  )
}

export default Page
