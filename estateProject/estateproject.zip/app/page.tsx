"use client"

import Page from "../src/app/page"

export default function SyntheticV0PageForDeployment() {
  return <Page />
}