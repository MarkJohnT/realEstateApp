"use client"

import { AdminDashboard } from "../src/components/admin-dashboard"

export default function SyntheticV0PageForDeployment() {
  return <AdminDashboard />
}